from gtts import gTTS

# A short Catholic-style song with pauses to make it sound more lyrical and sing-like
song_text = (
    "Ave Maria, full of grace, "
    "my heart sings to the Lord. "
    "Jesus, my Savior, shine Your light on me, "
    "guide my steps with love and peace. "
    "Hallelujah, hallelujah, "
    "I sing to You, my God. "
    "Blessed are You, Lord of heaven and earth, "
    "and I praise Your holy name. "
    "Amen, amen, my soul rejoices in Your love. "
)

# Use gTTS to create a smooth, sing-like spoken song
tts = gTTS(text=song_text, lang='en', slow=False)

# Save the audio file
output_file = "catholic_song.mp3"
tts.save(output_file)

print(f"Catholic-style song successfully saved to {output_file}!")